package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Koneksi {
    public static Connection conn;
    public static Connection koneksiDB()throws SQLException{
   try{
       String url = "jdbc:mysql://localhost:3306/data_mhs";
       String user = "root";
       String pass = "";
       DriverManager.registerDriver(new com.mysql.jdbc.Driver());
       conn = DriverManager.getConnection(url,user,pass);
       System.out.println("Berhasil");
   }catch(Exception e) {
       JOptionPane.showMessageDialog(null, "Gagal Koneksi"+e.getMessage());
    }
   return conn;
        }
   }