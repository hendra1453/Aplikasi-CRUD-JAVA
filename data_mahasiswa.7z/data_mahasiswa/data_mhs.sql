﻿# Host: localhost  (Version 5.6.21)
# Date: 2017-12-15 17:27:20
# Generator: MySQL-Front 6.0  (Build 2.20)


#
# Structure for table "data_mahasiswa"
#

DROP TABLE IF EXISTS `data_mahasiswa`;
CREATE TABLE `data_mahasiswa` (
  `nim` varchar(12) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `jk` varchar(45) DEFAULT NULL,
  `fakultas` varchar(45) DEFAULT NULL,
  `jurusan` varchar(45) DEFAULT NULL,
  `kontak` varchar(13) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "data_mahasiswa"
#

INSERT INTO `data_mahasiswa` VALUES ('1234','hendra','Laki-laki','FTI','Teknik Informatika','2321','dasd'),('344324','hendra','Laki-laki','FTI','Sistem Informasi','2131','eqeq');
